namespace NodeCanvas.DialogueTrees
{
    ///<summary>Sample locales. You can add/remove locales here</summary>
    public enum Locales
    {
        Default = 0, //Keep this
        Chinese,
        English,
        French,
        German,
        Greek,
        Italian,
        Japanese,
        Russian,
        Spanish,
    }
}